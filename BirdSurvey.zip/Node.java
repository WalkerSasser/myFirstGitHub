public class Node {
   
      Node next;
      int count = 1;
      String birdType;
   
      Node(String newBird) {
         birdType = newBird;
      }
   
   }