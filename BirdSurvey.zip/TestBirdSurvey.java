//Walker Sasser
//Assignment 5B
//Test Class
import java.util.Scanner;
public class TestBirdSurvey {
   public static void main (String[] args) {
   
      BirdSurvey birdList = new BirdSurvey();
   
      System.out.print("Enter birds: ");
   
      Scanner scan = new Scanner(System.in);
   
      String input1 = "";
   //String test = "done";
   
      while (!input1.equals("done")) {
      
         input1 = scan.nextLine();
      
         if(input1.equals("done"))
         break;
         
         birdList.add(new Node(input1));
      
      //scan.nextLine();
      }
   
      
      System.out.print("Enter bird type to see how many there are in the birdList: \n");
      String input = scan.nextLine();
      if (birdList.getCount(input) == 0)
         System.out.print("\nThere are no birds of that type in the survey. ");
      else 
         System.out.print("\nThere are " + birdList.getCount(input) + " " + input + "'s in the survey");
         
         System.out.println();
         
         System.out.print("\nReport of survey: \n" + birdList.getReport());
      
      scan.close();
   }
}