//Walker Sasser
//Assignement 5B
//May God Have Mercy on All Our Souls

public class BirdSurvey {
   Node head;


  /* public void add(String newBird) {
      if (head == null) {
         head = new Node(newBird);
         return;
      }
      if(head.birdType.equals(newBird)){
         head.count++;
         return;
      }
      Node current = head;
      //check to see if bird is already in list
      while (current != null) {
         if (current.birdType.equals(newBird)) { 
            current.count = current.count + 1;
            return;
         }
         current = current.next;
      }
      current = new Node(newBird);      
      return;
   }
   */
   public int getCount (String Bird) {
   
      Node current = head;
   
      while (current != null) {
      
         if (current.birdType.equals(Bird)){
            return current.count;
         }
         current = current.next;
      }
   
      return 0;
   
   }

   public String getReport() {
   
      String s = "";
   
      Node current = head;
   
      while (current != null) {
      
         s = s + current.birdType + ": " + current.count + "\n";
         
         current = current.next;
      }
      return s;
   }
   
   public void add(Node s){
      if(head == null){
         head = s;
         head.count = 1;
         return;
      }
      if(head.birdType.equals(s.birdType)){
         head.count++;
         return;
      }
      Node curr = head;
      while(true){
         if(curr.birdType.equals(s.birdType)){
            curr.count++;
            return;
         }
         if(curr.next == null){
            break;
         }
         curr = curr.next;
      }
      curr.next = s;
   }
}